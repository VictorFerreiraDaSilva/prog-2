#include <stdio.h>

int MODULO(int n){
    if(n<0) n*= -1;
    return n;
}

int main()
{
    int numero;
    scanf("%d", &numero);
    printf("Modulo: %d\n", MODULO(numero));

    return 0;
}
