#include <stdio.h>

int main() {
    int a;
    const int b = 1;
    int c = 2;
    short int d = 3;
    float e = 4;
    char f = 'A';
    //int vet[];
    // vet[]= {0,1};
    int vet[]={0,1};
    int vet0[a];
    int vet1[b];
    int vet2[c];
    int vet3[d];
    // int vet4[e];
    int vet5[f];
    int vet6[c==2];
    int vet7[7];
    return 0;
 }